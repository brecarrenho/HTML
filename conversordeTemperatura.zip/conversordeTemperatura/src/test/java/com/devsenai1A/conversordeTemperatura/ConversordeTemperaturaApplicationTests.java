package com.devsenai1A.conversordeTemperatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConversordeTemperaturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
